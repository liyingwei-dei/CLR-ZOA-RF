function N = fitness(pop, p, t)


n_trees = round(pop(1));
n_layer = round(pop(2));

p = p'; t = t'; 


num_size = length(t);


indices = crossvalind('Kfold', num_size, 5);

for i = 1 : 5
    
   
    valid_data = (indices == i);
    
   
    train_data = ~valid_data;
    
    
    pv_ = p_(train_data, :);
    tv_ = t_(train_data, :);
    
    pv_= p_(valid_data, :);
    tv_= t_(valid_data, :);

 
    model = regRF_train(pv_, tv_, n_trees, n_layer);

   
    t_sim = regRF_predict(pv_, model);

    error(i) = sqrt(sum((t - tv) .^ 2) ./ size(pv, 1));

end
N = mean(error);