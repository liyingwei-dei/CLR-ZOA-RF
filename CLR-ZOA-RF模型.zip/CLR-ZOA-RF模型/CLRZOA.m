warning off         
close all               
clear                
clc                  
res = xlsread('CF.xlsx','B2:G676');
num_size = 0.8;                             
outdim = 1;                                 
num_samples = size(res, 1);              
num_train_s = round(num_size * num_samples); 
f_ = size(res, 2) - outdim;                
P_train = res(1: num_train_s, 1: f_)';
T_train = res(1: num_train_s, f_ + 1: end)'
M = size(P_train, 2);
P_test = res(num_train_s + 1: end, 1: f_)';
T_test = res(num_train_s + 1: end, f_ + 1: end)';
N = size(P_test, 2);
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);
[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);
maxgen  = 60;                 
sizepop = 60;                 
popmax  = [   1000,   f_] ;   
popmin  = [   100,    1];
D=2;
miu=1.5;
for i = 1 : sizepop 
    pop(i, :) = log_sin_int(D,miu,popmin,popmax); 
    fit(i) = fun(pop(i, :), p_train, t_train);
end
for t=1:maxgen
   
    [best , location]=min(fit);
    if t==1
        PZ=pop(location,:);                                      
        fbest=best;                                         
        fbest=best;
        PZ=pop(location,:);
    end
    
    
    for i=1:sizepop
        
        I=round(1+rand);
         beta = 1.5; 
         alpha = 1;  
         sigma_u = (gamma(1+beta)*sin(pi*beta/2)/(beta*gamma((1+beta)/2)*2^((beta-1)/2)))^(1/beta);  % 计算u的分布标准差
         sigma_v = 1;  
         N1=1;
         u = normrnd(0, sigma_u, N1, D); 
         v = normrnd(0, sigma_v, N1, D);  
         X_newP1=pop(i,:)+ rand(1,2).*(PZ-I.* pop(i,:))+alpha.*step;%Eq(3)
         
         X_newP1= max(X_newP1,popmin);X_newP1 = min(X_newP1,popmax);
              f_newP1 = fun(X_newP1,p_train, t_train);
        if f_newP1 <= fit (i)
            pop(i,:) = X_newP1;
            fit (i)=f_newP1;
        end

    end
    
   
    Ps=rand;
    k=randperm(sizepop,1);
    AZ=pop(k,:);
    
    for i=1:sizepop
        
        if Ps<0.5
        
            R=0.1;
            X_newP2= pop(i,:)+ R*(2*rand(1,2)-1)*(1-t/maxgen).*pop(i,:);
            X_newP2= max(X_newP2,popmin);X_newP2 = min(X_newP2,popmax);
      
        else
          
            
            I=round(1+rand(1,1));
            X_newP2=pop(i,:)+ rand(1,2).*(AZ-I.* pop(i,:)); 
            X_newP2= max(X_newP2,popmin);X_newP2 = min(X_newP2,popmax);
             
        end
        
        f_newP2 = fun(X_newP2,p_train, t_train); 
        if f_newP2 <= fit (i)
            pop(i,:) = X_newP2;
            fit (i)=f_newP2;
        end

    end 
         sigma_v = 1; 
         N1=1;
    
         v = normrnd(0, sigma_v, N1, D); 
         if rand > 0.5 
         end
    best_so_far(t)=fbest;
    average(t) = mean (fit);
    
end
Best_score=fbest;
Best_pos=PZ;
ZOA_curve=best_so_far;
n_trees = round(PZ(1));
n_layer = round(PZ(2));

p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';
model = regRF_train(p_train, t_train, n_trees, n_layer);
importance = model.importance;
t_sim1 = regRF_predict(p_train, model);
t_sim2 = regRF_predict(p_test , model);

T_sim1 = mapminmax('reverse', t_sim1, ps_output);
T_sim2 = mapminmax('reverse', t_sim2, ps_output);
error1 = sqrt(sum((T_sim1' - T_train).^2) ./ M);
error2 = sqrt(sum((T_sim2' - T_test ).^2) ./ N);
figure
%%  相关指标计算
%  R2
R1 = 1 - norm(T_train - T_sim1')^2 / norm(T_train - mean(T_train))^2;
R2 = 1 - norm(T_test  - T_sim2')^2 / norm(T_test  - mean(T_test ))^2;

disp(['训练集数据的R2为：', num2str(R1)])
disp(['测试集数据的R2为：', num2str(R2)])

%  MAE
mae1 = sum(abs(T_sim1' - T_train)) ./ M ;
mae2 = sum(abs(T_sim2' - T_test )) ./ N ;

disp(['训练集数据的MAE为：', num2str(mae1)])
disp(['测试集数据的MAE为：', num2str(mae2)])

%  RMSE
rmse1 = sqrt(sum((T_sim1' - T_train).^2) ./ M);
rmse2 = sqrt(sum((T_sim2' - T_test).^2) ./ N);
disp(['训练集数据的RMSE为：', num2str(rmse1)])
disp(['测试集数据的RMSE为：', num2str(rmse2)])
% 计算mape
mape1 = sum(abs((T_sim1' - T_train))./T_train) ./ M ;
mape2 = sum(abs((T_sim2' - T_test ))./T_test) ./ N ;
disp(['训练集数据的MAPE为：', num2str(mape1)])
disp(['测试集数据的MAPE为：', num2str(mape2)])
