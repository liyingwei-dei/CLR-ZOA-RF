function x_apply =log_sin_int(dim,miu,Lb,Ub)
x=rand();%随机粒子

for i=1:dim-1
    x(i+1)=(miu*x(i)*(1-x(i))+(4-miu)*sin(pi*x(i))/4);
end
x_apply=Lb+x.*(Ub-Lb);
 

I=x_apply<Lb;
x_apply(I)=Lb(I);
U=x_apply>Ub;
x_apply(U)=Ub(U);
end
 